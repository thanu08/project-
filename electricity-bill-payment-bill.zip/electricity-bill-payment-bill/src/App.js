
import './App.css';
import { Bill } from './components/Bill';

function App() {
  return (
    <div>
      <Bill/>
    </div>
  );
}

export default App;
