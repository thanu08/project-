import React, {useEffect,useState} from "react";
import axios from "axios";
export function Bill() {

    const [email,setEmail] = useState('')
    const [emailFromBtn,setEmailFromBtn] = useState('')
    const [bill,setBill]= useState({})
    const [error,setError]=useState(false)

    useEffect(()=>
    {
        axios.get(`http://localhost:8080/bill/email/${email}`)
        .then(response=>
            {
                console.log(response.data)
                console.log(response.status)
                setBill(response.data)
                setError(false)
            })
            .catch(error=>
                {
                    console.log("error.msg")
                    setError(true)
                })
    },[emailFromBtn]
    
    )

   return (
       <div className="container">
           <h3>Search For Bill Details</h3>
           <hr/>
           <div className="form-group">
            <label>Customer Email</label>
            <input value={email} onChange={(event)=>setEmail(event.target.value)} className="form-control"/>
           </div>
           <button onClick={()=>setEmailFromBtn(email)} className="btn btn-primary mt-3">Search</button>
           <hr/>
           {
               !error?
           <div>
           <h3>Customer Email : {email}</h3>
           <ul className="list-group">
               <li>Bill Amount : {bill.billAmount}</li>
               <li>Bill Date : {bill.billDate} </li>
               <li>Bill Due Date : {bill.billDueDate}</li>
               <li>Units Consumed : {bill.unitsConsumed}</li>
           </ul>
           </div> : 
           <h5 className="text-danger">Bill Is Not Available</h5>
           }
       </div>
   )
}