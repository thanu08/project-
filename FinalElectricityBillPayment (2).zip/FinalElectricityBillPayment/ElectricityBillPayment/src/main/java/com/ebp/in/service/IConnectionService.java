package com.ebp.in.service;

import java.util.List;


import com.ebp.in.entity.Connection;
import com.ebp.in.exception.NoSuchConnectionException;
import com.ebp.in.exception.NoSuchCustomerException;


public interface IConnectionService {
	public Connection newConnectionRequest(Connection newConnection);
	public Connection searchCustomerByConsumerNumber(Long consumerNumber)throws NoSuchCustomerException;
//	public Connection updateConnectionAddress(Connection connection);
	// suspend or activate connection
//	public Connection modifyConnection(Connection connection);
	public List<Connection> findConnectionsByVillage(String village)throws NoSuchConnectionException;
	public List<Connection> findConnectionsByTaluka(String taluka)throws NoSuchConnectionException;
	public List<Connection> findConnectionsByDistrict(String district)throws NoSuchConnectionException;
	public List<Connection> findConnectionsByPincode(String pincode)throws NoSuchConnectionException;
	
	
	

}
