package com.ebp.in.service;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ebp.in.entity.Reading;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.repository.ReadingRepository;


@Service
public class ReadingService implements IReadingService {
	
	@Autowired
	private ReadingRepository read;
	
	@Autowired
	private IBillService billService;

	@Override
	public Reading selfsubmit(Reading reading) {
		Reading save=read.save(reading);
		return save;
	}

	@Override
	public List<Reading> findMeterReadingByConsumerNumber(Long consumerNumber) throws NoSuchCustomerException {
		List<Reading> readingcn=read.findByConsumerNumber(consumerNumber);
		if(readingcn==null)
		{
			throw new NoSuchCustomerException("Reading is not available for this consmer number"+consumerNumber);
		}else
		{
			return readingcn;
		}
	}

	@Override
	public Reading findMeterReadingByConsumerNumberAndBillDate(Long consumerNumber, LocalDate billDate)throws NoSuchCustomerException {
	    Reading readingcnbd=read.findByConsumerNumberAndBillDate(consumerNumber, billDate);
	    if(readingcnbd==null)
	    {
	    	throw new NoSuchCustomerException("Reading is not available for these consmer number"+consumerNumber+"and bill date"+billDate);
	    }else
	    {
	    	return readingcnbd;
	    }
		
	}

	
}
	