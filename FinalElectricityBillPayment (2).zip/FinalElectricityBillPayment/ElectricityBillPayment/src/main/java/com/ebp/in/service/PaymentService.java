package com.ebp.in.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ebp.in.entity.Payment;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.repository.PaymentRepository;


@Service

public class PaymentService implements IPaymentService
{
	@Autowired
	private PaymentRepository paymentrepo;


	@Override
	public List<Payment> viewHistoricalPayment(Long consumerNumber) throws NoSuchCustomerException {
		List<Payment> payment=paymentrepo.readHistoricalPaymentByConsumerNumber(consumerNumber);
		if(payment==null)
		{
			throw new NoSuchCustomerException("Reading is not available for this consmer number"+consumerNumber);
		}else
		{
			return payment;
		}
		
	}

	
}