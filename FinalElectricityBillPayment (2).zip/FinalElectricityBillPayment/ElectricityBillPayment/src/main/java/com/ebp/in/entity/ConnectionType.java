package com.ebp.in.entity;

import javax.persistence.Enumerated;

public enum ConnectionType {
	
	NON_INDUSTRIAL, INDUSTRIAL, AGRICULTURAL

}
