package com.ebp.in.controller;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ebp.in.entity.User;
import com.ebp.in.exception.InvalidLoginCredentialException;
import com.ebp.in.service.IUserService;

@RestController
@RequestMapping("/user") 
public class UserController{
	
	@Autowired
	private IUserService userService;
	
	@PostMapping("/registerUser")
	public ResponseEntity<User> registerUser(@Valid @RequestBody User user)
	{
		User registeredUser= userService.registerUser(user); 
		return new ResponseEntity<User>(registeredUser,HttpStatus.CREATED);
	}
	
	
	
	@PostMapping("/loginUser")
	public ResponseEntity<User> loginUser(@RequestBody User user)
	{
		User loggeduser = userService.loginUser(user);
		return new ResponseEntity<User>(loggeduser, HttpStatus.OK);

	}
	/*
	@PutMapping("/changepassword")
	public void changePassword(@RequestBody User user)
	{
		userService.changePassword(user);
	}
	
	@PutMapping("/forgotpassword")
	public void forgotPassword(@PathVariable String userName)
	{
		userService.forgotPassword(userName);
	}

	@PutMapping("emailpassword")
	public void emailPassword(@PathVariable String email)
	{
		userService.emailPassword(email);
	}*/
	
	@GetMapping("/searchUserByUserName/{userName}")
	public ResponseEntity<User> searchUserByUserName(@PathVariable String userName)
	{
		User byun = userService.searchUserByUserName(userName);
		return new ResponseEntity<User>(byun, HttpStatus.OK);
	}
	
	@GetMapping("/searchUserByUserId/{userId}")
	public ResponseEntity<User> searchUserByUserId(@PathVariable Long userId)
	{
		User byid = userService.searchUserByUserId(userId);
		return new ResponseEntity<User>(byid, HttpStatus.OK);
	}
	
	
}




