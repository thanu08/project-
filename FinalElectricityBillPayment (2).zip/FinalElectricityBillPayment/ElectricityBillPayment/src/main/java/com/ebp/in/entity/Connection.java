package com.ebp.in.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "connection_table")
public class Connection {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long connectionId;
	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="consumer_no")
	private Long consumerNumber;
	
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="user_fk",referencedColumnName = "user_id")
	private Customer customerConnection;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="address_id",referencedColumnName ="addressId")
	private Address connectionAddress;
	
	@Column(name="connection_type")
	@Enumerated(EnumType.STRING)
	private ConnectionType connectionType;
	
	
	@Column(name = "applicationdate")
	private LocalDate applicationDate;
	
	@Column(name = "connectiondate")
	private LocalDate connectionDate;
	
	
	@Column(name="village")
	private String village;
	@Column(name="taluka")
	private String taluka;
	@Column(name="district")
	private String district;
	@Column(name="pincode")
	private String pincode;

	public Connection() {
		
	}

	
	

	public Connection(Long connectionId, Long consumerNumber,Customer customerConnection, Address connectionAddress,
			ConnectionType connectionType, LocalDate applicationDate, LocalDate connectionDate,
			 String village, String taluka, String district, String pincode) {
		super();
		this.connectionId = connectionId;
		this.consumerNumber = consumerNumber;
		this.customerConnection = customerConnection;
		this.connectionAddress = connectionAddress;
		this.connectionType = connectionType;
		this.applicationDate = applicationDate;
		this.connectionDate = connectionDate;
		this.village = village;
		this.taluka = taluka;
		this.district = district;
		this.pincode = pincode;
	}

	public Long getConnectionId() {
		return connectionId;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	public String getTaluka() {
		return taluka;
	}

	public void setTaluka(String taluka) {
		this.taluka = taluka;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public void setConnectionId(Long connectionId) {
		this.connectionId = connectionId;
	}

	public Long getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(Long consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	public Customer getCustomerConnection() {
		return customerConnection;
	}

	public void setCustomerConnection(Customer customerConnection) {
		this.customerConnection = customerConnection;
	}

	public Address getConnectionAddress() {
		return connectionAddress;
	}

	public void setConnectionAddress(Address connectionAddress) {
		this.connectionAddress = connectionAddress;
	}

	public ConnectionType getConnectionType() {
		return connectionType;
	}

	public void setConnectionType(ConnectionType connectionType) {
		this.connectionType = connectionType;
	}

	public LocalDate getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(LocalDate applicationDate) {
		this.applicationDate = applicationDate;
	}

	public LocalDate getConnectionDate() {
		return connectionDate;
	}

	public void setConnectionDate(LocalDate connectionDate) {
		this.connectionDate = connectionDate;
	}

	
	
	
}
