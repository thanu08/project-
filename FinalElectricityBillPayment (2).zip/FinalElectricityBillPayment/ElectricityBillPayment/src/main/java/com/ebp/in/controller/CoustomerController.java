package com.ebp.in.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.service.ICustomerService;

@RestController
@RequestMapping(value="/customer")
public class CoustomerController {
	
	@Autowired
	private ICustomerService customerService;
	
	@PostMapping(value="/register")
	public ResponseEntity<Customer> registerCustomer(@Valid @RequestBody Customer customer)
	{
		Customer registeredCustomer= customerService.registerCustomer(customer);
		return new ResponseEntity<Customer>(registeredCustomer,HttpStatus.CREATED);
	}
	
	@GetMapping(value="/viewCustomersProfile")
	public ResponseEntity<List<Customer>> viewCustomersProfile(){
		List<Customer> getAll= customerService.viewCustomersProfile();
		return new ResponseEntity<List<Customer>>(getAll,HttpStatus.OK);
	}
	
	@PutMapping(value="/editCustomerProfile")
	public ResponseEntity<Customer> editCustomerProfile(Long customerId,Customer customer){
		Customer updatedCustomer= customerService.editCustomerProfile(customerId,customer);
		return new ResponseEntity<Customer>(updatedCustomer,HttpStatus.OK);
	}
	
	
	@GetMapping(value="/byid/{customerId}")
	public ResponseEntity<Customer> searchCustomerByCustomerId(@PathVariable Long customerId) throws NoSuchCustomerException{
		
		Customer byId= customerService.searchCustomerByCustomerId(customerId);
		return new ResponseEntity<Customer>(byId,HttpStatus.OK);
		
	}
	
	@GetMapping(value="/byemail/{email}")
	public ResponseEntity<Customer> searchCustomerByEmail(@PathVariable String email) throws NoSuchCustomerException{
		
		Customer byEmail= customerService.searchCustomerByEmail(email);
		return new ResponseEntity<Customer>(byEmail,HttpStatus.OK);
		
	}
	
	@GetMapping(value="/customerbyadar/{addharNumber}")
	public ResponseEntity<Customer> searchCustomerByAadhar(@PathVariable Long addharNumber) throws NoSuchCustomerException{
		
		Customer byAadhar= customerService.searchCustomerByAadhar(addharNumber);
		return new ResponseEntity<Customer>(byAadhar,HttpStatus.OK);
		
	}
	
	@GetMapping(value="/customerbymn/{mobileNumber}")
	public ResponseEntity<Customer> searchCustomerByMobielNumber(@PathVariable String mobileNumber) throws NoSuchCustomerException{
		
		Customer byMobile= customerService.searchCustomerByEmail(mobileNumber);
		return new ResponseEntity<Customer>(byMobile,HttpStatus.OK);
		
	}
	
	
	@GetMapping(value="/customerbyfn/{firstName}")
	public ResponseEntity<List<Customer>> searchCustomerByFirstName(@PathVariable String firstName) throws NoSuchCustomerException{
		 
		List<Customer> byName= customerService.searchCustomerByName(firstName);	
		return new ResponseEntity<List<Customer>>(byName,HttpStatus.OK);
		
	}
	
}