package com.ebp.in.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Customer_Table")
public class Customer extends User {
	
	
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private Long customerId;
	@Column(unique = true,nullable = false)
	@NotNull(message ="Addhar no is Required")
	private Long addharNumber;
	@Column
	@NotEmpty(message ="Name is Required")
	private String firstName;
	@Column
	private String middleName;
	@Column
	private String lastName;
	@Column(unique = true,nullable = false)
	@NotEmpty(message ="Mobile no is Required")
	private String mobileNumber;
	@Column(unique = true,nullable = false)
	@NotEmpty(message ="Email is Required")
	private String email;
	@Column
	private String gender;

}
