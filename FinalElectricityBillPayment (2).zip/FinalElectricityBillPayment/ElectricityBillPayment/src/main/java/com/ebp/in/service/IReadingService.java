package com.ebp.in.service;

import java.time.LocalDate;

import java.util.List;


import com.ebp.in.entity.Reading;
import com.ebp.in.exception.NoSuchCustomerException;

public interface IReadingService {
	
	public Reading selfsubmit(Reading reading);
	public List<Reading> findMeterReadingByConsumerNumber(Long consumerNumber)throws NoSuchCustomerException;
	public Reading findMeterReadingByConsumerNumberAndBillDate(Long consumerNumber, LocalDate billDate)throws NoSuchCustomerException;
}



