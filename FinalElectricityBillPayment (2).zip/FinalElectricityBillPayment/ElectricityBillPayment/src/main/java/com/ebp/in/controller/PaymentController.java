package com.ebp.in.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ebp.in.entity.Payment;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.service.IPaymentService;

@RestController

public class PaymentController {

	@Autowired
	private IPaymentService paymentService;
	
	@GetMapping(value="/consumerNumber/{consumerNumber}")
	public ResponseEntity<List<Payment>> viewHistoricalPayment(@PathVariable Long consumerNumber)throws NoSuchCustomerException
	{
		List<Payment> readByconsumerNumber=paymentService.viewHistoricalPayment(consumerNumber);
		return new ResponseEntity<List<Payment>>(readByconsumerNumber,HttpStatus.OK);				
	}
}
