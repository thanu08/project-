package com.ebp.in.entity;

import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="payment_table")
public class Payment  {	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="paymentId")
	private Long paymentId;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="bill_id",referencedColumnName="billId")
	private Bill billPayment;
	
	@Column(name="paymentDate")
	private LocalDate paymentDate;
	
	@Enumerated(EnumType.STRING)
	@Column(name="paymentMode")
	private PaymentMode paymentMode;
	
	@Column(name="latePaymentCharges")
	private double latePaymentCharges;
	
	@Column(name="totalPaid")
	private double totalPaid;
	
	@Enumerated(EnumType.STRING)
	@Column(name="status")
	private PaymentStatus status;
	

	@Column(name="consumerNumber")
	private Long consumerNumber;
	
	public Payment() {
		
	}

	public Payment(Long paymentId, LocalDate paymentDate, PaymentMode paymentMode, double latePaymentCharges,
			double totalPaid, PaymentStatus status, Long consumerNumber) {
		
		this.paymentId = paymentId;
		this.paymentDate = paymentDate;
		this.paymentMode = paymentMode;
		this.latePaymentCharges = latePaymentCharges;
		this.totalPaid = totalPaid;
		this.status = status;
		this.consumerNumber = consumerNumber;
	}

	public Long getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(Long paymentId) {
		this.paymentId = paymentId;
	}

	public LocalDate getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		this.paymentDate = paymentDate;
	}

	public PaymentMode getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(PaymentMode paymentMode) {
		this.paymentMode = paymentMode;
	}

	public double getLatePaymentCharges() {
		return latePaymentCharges;
	}

	public void setLatePaymentCharges(double latePaymentCharges) {
		this.latePaymentCharges = latePaymentCharges;
	}

	public double getTotalPaid() {
		return totalPaid;
	}

	public void setTotalPaid(double totalPaid) {
		this.totalPaid = totalPaid;
	}

	public PaymentStatus getStatus() {
		return status;
	}

	public void setStatus(PaymentStatus status) {
		this.status = status;
	}

	public Long getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(Long consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", paymentDate=" + paymentDate + ", paymentMode=" + paymentMode
				+ ", latePaymentCharges=" + latePaymentCharges + ", totalPaid=" + totalPaid + ", status=" + status
				+ ", consumerNumber=" + consumerNumber + "]";
	}

	}