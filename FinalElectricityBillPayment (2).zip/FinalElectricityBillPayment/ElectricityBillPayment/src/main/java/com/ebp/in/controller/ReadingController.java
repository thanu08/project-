package com.ebp.in.controller;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ebp.in.entity.Reading;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.service.IReadingService;

@RestController
@RequestMapping("/reading")

public class ReadingController {

	@Autowired
	private IReadingService readingService;
	
	@PostMapping(value="/submit")
	public ResponseEntity<Reading> save(@RequestBody Reading reading)
	{
		Reading submit=readingService.selfsubmit(reading);
		return new ResponseEntity<Reading>(submit,HttpStatus.CREATED);	
	}
	
	@GetMapping(value="/consumerNumber/{consumerNumber}")
	public ResponseEntity<List<Reading>> findMeterReadingByConsumerNumber(@PathVariable Long consumerNumber)throws NoSuchCustomerException
	{
		List<Reading> readByconsumerNumber=readingService.findMeterReadingByConsumerNumber(consumerNumber);
		return new ResponseEntity<List<Reading>>(readByconsumerNumber,HttpStatus.OK);				
	}
	
	@GetMapping(value="/consumerNumberbillDate/{consumerNumber},{billDate}")
	public ResponseEntity<Reading> findMeterReadingByConsumerNumberAndBillDate(@PathVariable Long consumerNumber,@PathVariable LocalDate billDate)throws NoSuchCustomerException
	{
		Reading readByconsumerNumberAndBillDate=readingService.findMeterReadingByConsumerNumberAndBillDate(consumerNumber, billDate);
		return new ResponseEntity<Reading>(readByconsumerNumberAndBillDate,HttpStatus.OK);
	}
}
