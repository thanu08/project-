package com.ebp.in.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ebp.in.entity.Connection;
//import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchConnectionException;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.service.IConnectionService;

@RestController
@RequestMapping(value =  "/connection")
public class ConnectionController {
	
	@Autowired
	private IConnectionService connectionService;
	
/*	@PostMapping("/newrequest")
	public ResponseEntity<Connection> newConnectionRequest(@RequestBody Connection connection)
	{
		Connection  newConnectionRequest=connectionService.newConnectionRequest(connection);
		return new ResponseEntity<Connection>(newConnectionRequest,HttpStatus.CREATED);
	}*/
	
	@PostMapping(value="/newRequest")
	public ResponseEntity<Connection> newConnectionRequest(@Valid @RequestBody Connection newConnection)
	{
		Connection requestedConnection= connectionService.newConnectionRequest(newConnection);
		return new ResponseEntity<Connection>(requestedConnection,HttpStatus.CREATED);
	}

	
	@GetMapping("/{consumerNumber}")
	public ResponseEntity<Connection> searchCustomerByConsumerNumber(@PathVariable Long consumerNumber) throws NoSuchCustomerException
	{
		Connection cn=connectionService.searchCustomerByConsumerNumber(consumerNumber);
		return new ResponseEntity<Connection>(cn,HttpStatus.OK);	
		}
/*
	@PutMapping("/modifyConnectionAddress")
	public ResponseEntity<Connection> modifyConnectionAddress(@RequestBody Connection connection)
	{
		Connection modifyConnectionAddress=connectionService.modifyConnectionAddress(connection);
		return new ResponseEntity<Connection>(modifyConnectionAddress,HttpStatus.CREATED);
	}
	*/

	@GetMapping(value="/village/{villageName}")
	public ResponseEntity<List<Connection>> findConnectionsByVillage(@PathVariable String village)throws NoSuchCustomerException
	{
		List<Connection> connectionByVillage=connectionService.findConnectionsByVillage(village);
		return new ResponseEntity<List<Connection>>(connectionByVillage,HttpStatus.OK);				
	}

	
	@GetMapping(value="/taluka/{taluka}")
	public ResponseEntity<List<Connection>> findConnectionsByTaluka(@PathVariable String taluka)throws NoSuchCustomerException
	{
		List<Connection> connectionByTaluka=connectionService.findConnectionsByTaluka(taluka);
		return new ResponseEntity<List<Connection>>(connectionByTaluka,HttpStatus.OK);				
	}
	
	@GetMapping(value="/district/{districtName}")
	public ResponseEntity<List<Connection>> findConnectionsByDistrict(@PathVariable String district)throws NoSuchCustomerException
	{
		List<Connection> connectionByDistrict=connectionService.findConnectionsByDistrict(district);
		return new ResponseEntity<List<Connection>>(connectionByDistrict,HttpStatus.OK);				
	}
	
	@GetMapping(value="/pincode/{pincode}")
	public ResponseEntity<List<Connection>> findConnectionsBypincode(@PathVariable String pincode)throws NoSuchCustomerException
	{
		List<Connection> connectionByPincode=connectionService.findConnectionsByPincode(pincode);
		return new ResponseEntity<List<Connection>>(connectionByPincode,HttpStatus.OK);				
	}
	
	
	
	
	
	
}

