package com.ebp.in.entity;


import java.time.LocalDate;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="reading_table")
public class Reading {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="readingId")
	private Long readingId;
	
	@Column(name="unitsConsumed")
	private Integer unitsConsumed;
	
	@Column(name="readingPhoto")
	private String readingPhoto;
	
	@Column(name="readingDate")
	private LocalDate readingDate;
	
	@Column(name="pricePerUnits")
	private Integer pricePerUnits;
	
	@Column(name="consumerNumber")
	private Long consumerNumber;
	
	@Column(name="billDate")
	private LocalDate billDate;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="connectionid_fk", referencedColumnName="connectionId")
	private Connection readingForConnection;
	
	public Reading() {
		
	}

	public Reading(Long readingId, Integer unitsConsumed, String readingPhoto, LocalDate readingDate,
			Integer pricePerUnits, Long consumerNumber, LocalDate billDate) {
	
		this.readingId = readingId;
		this.unitsConsumed = unitsConsumed;
		this.readingPhoto = readingPhoto;
		this.readingDate = readingDate;
		this.pricePerUnits = pricePerUnits;
		this.consumerNumber = consumerNumber;
		this.billDate = billDate;
	}

	public Long getReadingId() {
		return readingId;
	}

	public void setReadingId(Long readingId) {
		this.readingId = readingId;
	}

	public Integer getUnitsConsumed() {
		return unitsConsumed;
	}

	public void setUnitsConsumed(Integer unitsConsumed) {
		this.unitsConsumed = unitsConsumed;
	}

	public String getReadingPhoto() {
		return readingPhoto;
	}

	public void setReadingPhoto(String readingPhoto) {
		this.readingPhoto = readingPhoto;
	}

	public LocalDate getReadingDate() {
		return readingDate;
	}

	public void setReadingDate(LocalDate readingDate) {
		this.readingDate = readingDate;
	}

	public Integer getPricePerUnits() {
		return pricePerUnits;
	}

	public void setPricePerUnits(Integer pricePerUnits) {
		this.pricePerUnits = pricePerUnits;
	}

	public Long getConsumerNumber() {
		return consumerNumber;
	}

	public void setConsumerNumber(Long consumerNumber) {
		this.consumerNumber = consumerNumber;
	}

	public LocalDate getBillDate() {
		return billDate;
	}

	public void setBillDate(LocalDate billDate) {
		this.billDate = billDate;
	}

	
}