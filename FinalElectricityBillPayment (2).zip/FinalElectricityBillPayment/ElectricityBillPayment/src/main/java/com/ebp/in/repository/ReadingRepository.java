package com.ebp.in.repository;


import java.time.LocalDate;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ebp.in.entity.Reading;


public interface ReadingRepository extends JpaRepository<Reading,Integer> {

	public List<Reading> findByConsumerNumber(Long consumerNumber);
	public Reading findByConsumerNumberAndBillDate(Long consumerNumber, LocalDate billDate);

}
