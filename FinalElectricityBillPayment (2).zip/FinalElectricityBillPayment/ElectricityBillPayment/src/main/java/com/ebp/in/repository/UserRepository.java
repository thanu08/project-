package com.ebp.in.repository;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ebp.in.entity.User;
import com.ebp.in.exception.NoSuchUserException;


@Repository

public interface UserRepository extends JpaRepository<User,Long> {
	
	@Query(value="select * from user u ", nativeQuery=true)
	public User loginUser(User user);
	//public void changePassword(User user);
	//public void forgotPassword(String userName);
	public User findByUserName(String userName);
	public User findByUserId(Long userId);
	
	
	/*
	public User createUser(User user);
	public User loginUser(User user);
	public void changePassword(User user);
	public void forgotPassword(String userName);
	
	
	
	public User setUserId1(Long userId);
	public void emailPassword(String email);
	public User findByUserName(String userName);
	public User findByUserId(int userId);
	public void savechangePassword(User user);
	public void saveforgotPassword(String userName);
	public void saveemailPassword(String email);
	public String getPassword();
	public Optional<User> findById(User user);
	public Optional<User> findByName(String userName);
	public User findByEmail(String email);
	public Optional<User> findById(int userId);
	public Optional<User> findById1(Long userId);
	
	
*/
	
	
	


}
