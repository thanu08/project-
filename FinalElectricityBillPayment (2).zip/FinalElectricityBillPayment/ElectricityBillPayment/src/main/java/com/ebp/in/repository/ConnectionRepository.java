package com.ebp.in.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ebp.in.entity.Connection;
//import com.ebp.in.entity.Customer;


@Repository

public interface ConnectionRepository extends JpaRepository<Connection, Long> {
//	public Connection createNewConnection(Connection newConnection);
	public Connection readCustomerByConsumerNumber(Long consumerNumber);
//	public Connection updateConnectionAddress(Connection connection);
//	public Connection updateConnection(Connection connection);
	
	public List<Connection> findConnectionsByVillage(String village);
	public List<Connection> findConnectionsByTaluka(String taluka);
	public List<Connection> findConnectionsByDistrict(String district);
	public List<Connection> findConnectionsByPincode(String pincode);
	


	
	
	
/*	@Query("select c from Customer c where c.consumerNumber=?1")
	public Customer readCustomerByConsumerNumber(Long consumerNumber);
	
	@Query("select c from Connection c where c.villageName=?1")
	public List<Connection> readActiveConnectionsByVillage(String villageName);
	
	@Query("select c from Connection c where c.taluka=?1")
	public List<Connection> readActiveConnectionsByTaluka(String taluka);
	
	@Query("select c from Connection c where c.districtName=?1")
	public List<Connection> readActiveConnectionsByDistrict(String districtName);
	
	@Query("select c from Connection c where c.pincode=?1")
	public List<Connection> readActiveConnectionsByPincode(String pincode);
	
	@Query("select c from Connection c where c.villageName=?1")
	public List<Connection> readInactiveConnectionsByVillage(String villageName);
	
	@Query("select c from Connection c where c.taluka=?1")
	public List<Connection> readInactiveConnectionsByTaluka(String taluka);
	
	@Query("select c from Connection c where c.districtName=?1")
	public List<Connection> readInactiveConnectionsByDistrict(String districtName);
	
	@Query("select c from Connection c where c.pincode=?1")
	public List<Connection> readInactiveConnectionsByPincode(String pincode);
	
	
*/

}
