package com.ebp.in.service;

import java.time.LocalDate;

import java.util.List;

import com.ebp.in.entity.Bill;
import com.ebp.in.entity.ConnectionType;
//import com.ebp.in.entity.ConnectionType;
//import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchCustomerException;

public interface IBillService 
{
	public Bill viewBillByConsumerNumber(Long consumerNumber) throws NoSuchCustomerException;
	public Bill viewBillByMobileNumber(String mobile) throws NoSuchCustomerException;
	public Bill viewBillByEmail(String email) throws NoSuchCustomerException;
	public List<Bill> viewBillForDateRange(LocalDate from, LocalDate to) throws NoSuchCustomerException;
	public double enrgeyBillCalculator(ConnectionType type, double unitsConsumed);
	public void emailBillToCustomer(Long consumerNumber, String email)throws NoSuchCustomerException;

}
