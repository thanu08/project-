package com.ebp.in.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ebp.in.entity.Connection;
//import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchConnectionException;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.repository.ConnectionRepository;
import com.ebp.in.repository.CustomerRepository;
//import com.ebp.in.repository.CustomerRepository;

@Service
public class ConnectionServiceImplementation implements IConnectionService {
	
	@Autowired
	private ConnectionRepository connectionRepository;
	
	@Autowired
	private CustomerRepository customerRepository;

	@Override
	public Connection newConnectionRequest(Connection newConnection) {
	Connection newConnectionRequest=connectionRepository.save(newConnection);
	return newConnectionRequest;
	}
	
	

	


	@Override
	public Connection searchCustomerByConsumerNumber(Long consumerNumber) throws NoSuchCustomerException {
		Connection cn=connectionRepository.readCustomerByConsumerNumber(consumerNumber);
		if(cn==null)
		{
			throw new NoSuchCustomerException("No customer available for this consumer number" +consumerNumber);
		}else
		{
			return cn;
		}
	}
	
/*	
	@Override
	public Connection updateConnectionAddress(Connection connection) {
		Connection modifyConnection=connectionRepository.updateConnectionAddress(connection);
		return modifyConnection;
	
	}
*/


	  @Override
	public List<Connection> findConnectionsByVillage(String villageName) throws NoSuchConnectionException {
		List<Connection> connection=connectionRepository.findConnectionsByVillage(villageName);
		if(connection==null)
		{
			throw new NoSuchConnectionException("connections are not available for this village name:"+villageName);
		}else
		{
			return connection;
		}
	}
	  
	  @Override
		public List<Connection> findConnectionsByTaluka(String taluka) throws NoSuchConnectionException {
			List<Connection> connection=connectionRepository.findConnectionsByTaluka(taluka);
			if(connection==null)
			{
				throw new NoSuchConnectionException("connections are not available for this taluka"+taluka);
			}else
			{
				return connection;
			}
		}
	  
	  @Override
		public List<Connection> findConnectionsByDistrict(String districtName) throws NoSuchConnectionException {
			List<Connection> connection=connectionRepository.findConnectionsByDistrict(districtName);
			if(connection==null)
			{
				throw new NoSuchConnectionException("connections are not available for this District"+districtName);
			}else
			{
				return connection;
			}
		}
	  
	  @Override
		public List<Connection> findConnectionsByPincode(String pincode) throws NoSuchConnectionException {
			List<Connection> connection=connectionRepository.findConnectionsByPincode(pincode);
			if(connection==null)
			{
				throw new NoSuchConnectionException("connections are not available for this Pincode"+pincode);
			}else
			{
				return connection;
			}
		}

	
	  
	 


	 


	
}
