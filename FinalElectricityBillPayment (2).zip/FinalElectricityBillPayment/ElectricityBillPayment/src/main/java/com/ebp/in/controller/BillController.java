package com.ebp.in.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ebp.in.entity.Bill;
//import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.service.IBillService;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/bill")
public class BillController 
{
	@Autowired
	private IBillService billService;
	
	@GetMapping(value="/consumernumber/{consumerNumber}")
	public ResponseEntity<Bill> viewBillByConsumerNumber(@PathVariable Long consumerNumber) throws NoSuchCustomerException
	{
		Bill billByConsumerNumber = billService.viewBillByConsumerNumber(consumerNumber);
		return new ResponseEntity<Bill>(billByConsumerNumber, HttpStatus.OK);
		
				
	}
	
	@GetMapping(value="/mobilenumber/{mobileNumber}")
	public ResponseEntity<Bill> viewBillByMobileNumber(@PathVariable String mobileNumber) throws NoSuchCustomerException
	{
		Bill billByMobileNumber = billService.viewBillByMobileNumber(mobileNumber);
				return new ResponseEntity<Bill>(billByMobileNumber, HttpStatus.OK);
	}
	
	@GetMapping(value="/email/{email}")
	public ResponseEntity<Bill> viewBillByEmail(@PathVariable String email) throws NoSuchCustomerException
	{
		Bill billByEmail = billService.viewBillByEmail(email);
				return new ResponseEntity<Bill>(billByEmail, HttpStatus.OK);
	}
	
	@GetMapping(value="/dateRange")
	public ResponseEntity<List<Bill>> viewBillForDateRange(LocalDate from, LocalDate to) throws NoSuchCustomerException
	{
		List<Bill> billForDateRange = billService.viewBillForDateRange(from, to);
		return new ResponseEntity<List<Bill>>(billForDateRange, HttpStatus.OK);
	}
	

}
