package com.ebp.in.service;

import java.time.LocalDate;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ebp.in.entity.Bill;
import com.ebp.in.entity.ConnectionType;
//import com.ebp.in.entity.ConnectionType;
//import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchCustomerException;
import com.ebp.in.repository.BillRepository;
import com.ebp.in.repository.CustomerRepository;

@Service
public class BillServiceImpl implements IBillService
{
	@Autowired
	private BillRepository billRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public Bill viewBillByConsumerNumber(Long consumerNumber)  throws NoSuchCustomerException
	{
		Bill bill = billRepository.findByConsumerNumber(consumerNumber);
		
		if(bill==null)
		{
			throw new NoSuchCustomerException("Bill Not Available For Consumer Number"+consumerNumber);
		}
		else
		{
			return bill;
		}
		
		
	}

	@Override
	public Bill viewBillByMobileNumber(String mobile) throws NoSuchCustomerException 
	{
		Bill billmn = billRepository.findByMobileNumber(mobile);
		if(billmn==null)
		{
			throw new NoSuchCustomerException("Bill Not Available For Given Mobile Number"+mobile);
		}
		else
		{
			return billmn;
		}
		
	}

	@Override
	public Bill viewBillByEmail(String email) throws NoSuchCustomerException 
	{
		Bill billemail = billRepository.findByEmail(email);
		if(billemail==null)
		{
			throw new NoSuchCustomerException("Bill Not Available For Given Email"+email);
		}
		else
		{
			return billemail;
		}
		
	}

	@Override
	public List<Bill> viewBillForDateRange(LocalDate from, LocalDate to) throws NoSuchCustomerException
	{	try {
		return billRepository.findAllByBillDateBetween(from, to);
	}
	catch(Exception e)
	{
		throw new NoSuchCustomerException("Bill Is Not Available For Date from"+from +"to" +to);
	}
	}

	@Override
	public double enrgeyBillCalculator(ConnectionType type, double unitsConsumed) 
	{	
		return 0.0;
	}

	@Override
	public void emailBillToCustomer(Long consumerNumber, String email) throws NoSuchCustomerException 
	{
		/*if(billRepository.findByCunsumerNumberAndEmail(consumerNumber,email).isEmpty())
		{
			throw new NoSuchCustomerException("Bill Not Available For Given ConsumerNumber and Email"+consumerNumber,email);
		}*/
		
		
	}

}
