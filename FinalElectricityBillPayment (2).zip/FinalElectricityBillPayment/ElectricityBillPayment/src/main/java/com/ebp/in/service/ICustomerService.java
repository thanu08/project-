package com.ebp.in.service;

import java.util.List;


import com.ebp.in.entity.Customer;
import com.ebp.in.exception.NoSuchCustomerException;



public interface ICustomerService {
	
	
	Customer registerCustomer(Customer customer);
	
	public List<Customer> viewCustomersProfile();
	
	public Customer editCustomerProfile(Long customerId,Customer customer);
	
	public Customer searchCustomerByCustomerId(Long customerId) throws NoSuchCustomerException;
	
	public Customer searchCustomerByEmail(String email) throws NoSuchCustomerException;
	
	public Customer searchCustomerByAadhar(Long aadharNumber) throws NoSuchCustomerException;
	
	public Customer searchCustomerByMobile(String mobileNumber) throws NoSuchCustomerException;
	
	public List<Customer> searchCustomerByName(String firstName) throws NoSuchCustomerException;

	
	
	
}
