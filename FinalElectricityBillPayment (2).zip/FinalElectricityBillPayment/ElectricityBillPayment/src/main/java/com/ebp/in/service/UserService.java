package com.ebp.in.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ebp.in.entity.User;
import com.ebp.in.exception.DuplicateUserException;
import com.ebp.in.exception.InvalidLoginCredentialException;
import com.ebp.in.exception.NoSuchUserException;
import com.ebp.in.repository.UserRepository;

@Service
public  class UserService implements IUserService {
	
	@Autowired
	private UserRepository userrepo;

	@Override
	public User registerUser(User user) throws DuplicateUserException {
		
		return userrepo.save(user); 
	}
	
	@Override
	public User loginUser(User user) throws InvalidLoginCredentialException {
		User loginuser = userrepo.loginUser(user);
		if(loginuser==null)
		{
			throw new InvalidLoginCredentialException("User Not Exists");
		}
		return loginuser;
	}
	
/*
	@Override
	public void changePassword(User user) {
		
	}

	@Override
	public void forgotPassword(String userName) {
		
		
	}

	@Override
	public void emailPassword(String email) {
		
		
	}*/

	@Override
	public User searchUserByUserName(String userName) throws NoSuchUserException {
		
       User byUserName = userrepo.findByUserName(userName);
		
		if(byUserName==null)
		{
			throw new NoSuchUserException("User Not Exist!");
		}
		else
		{
			return byUserName;
		}
	}

	@Override
	public User searchUserByUserId(Long userId) throws NoSuchUserException {
		User byUserId = userrepo.findByUserId(userId);
				if(byUserId==null)
				{
					throw new NoSuchUserException("User Not Exist!");
				}
				else
				{
					return byUserId;
				}
	}



	

	
}
	




/*

@Override
public boolean registerUser(User user) throws DuplicateUserException {
	 {
			
		 Optional<User> p = userrepo.findById(user.getUserId());
		 	
		 	if (p.isPresent())
		  throw new DuplicateUserException("User is already present");
		 		
		 userrepo.save(user);
		 	
		 	return true;
		 	
		 }


}

@Override
public boolean loginUser(User user) throws InvalidLoginCredentialException {
	Optional<User> l = userrepo.findById(User.getLoginid());
	
	try {
		if (!User.getLoginid().equals(l.get().getPassword()))
					
		throw new InvalidClassException("user Id and password not matching");
	} catch (InvalidClassException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			
	return true;
	
}

@Override
public void changePassword(User user) {
	Optional<User> l = userrepo.findById(user);
	
	if (!l.isPresent())
	 {
				
	throw new NoSuchUserException("No User is found with login:" + user);
		
		}
			
	System.out.println("Password for your Account is" + userrepo.getPassword());
		
	}
	


@Override
public void forgotPassword(String userName) {
	Optional<User> l = userrepo.findByName(userName);
	
	if (!l.isPresent())
	 {
				
	throw new NoSuchUserException("No User is found with loginId:" + userName);
		
		}
			
	System.out.println("Password for your Account is" + userrepo.getPassword());
	
}

@Override
public void emailPassword(String email) {
	User p = userrepo.findByEmail(email);
	
	if (p.isActive())
	 {
				
	throw new NoSuchUserException("User is not found");
		
		}
			
	return;
	
}

@Override
public User searchUserByUserName(String userName) throws NoSuchUserException {
	Optional<User> p = userrepo.findByName(userName);
	
	if (!p.isPresent())
	{
	 throw new NoSuchUserException("No User for this Name");
	}	
	return p.get();

}

	


@Override
public User searchUserByUserId(int userId) throws NoSuchUserException {
	Optional<User> p = userrepo.findById(userId);
	
	if (!p.isPresent()) {
	 throw new NoSuchUserException("No User for this ID");
	}
			
	return p.get();

	
}

@Override
public User searchUserByUserId1(Long userId) throws NoSuchUserException {
	Optional<User> p = userrepo.findById1(userId);
	
	if (!p.isPresent()) {
	 throw new NoSuchUserException("No User for this ID");
	}
			
	return p.get();


}*/

	