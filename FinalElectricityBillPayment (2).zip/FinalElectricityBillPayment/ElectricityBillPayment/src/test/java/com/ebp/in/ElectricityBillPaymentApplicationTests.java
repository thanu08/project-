package com.ebp.in;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectricityBillPaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
